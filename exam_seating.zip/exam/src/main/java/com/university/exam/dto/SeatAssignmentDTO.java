package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SeatAssignmentDTO {
    private Long seatingPlanId;
    private Long roomId;
    private Long studentId;
    private Integer seatRow;
    private Integer seatCol;
}
