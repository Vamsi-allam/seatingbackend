package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomDTO {
    private Long id;
    private String name;
    private Integer rows;
    private Integer cols;
    private Integer floorId;
}
