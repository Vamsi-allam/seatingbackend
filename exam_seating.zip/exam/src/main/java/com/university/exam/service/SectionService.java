package com.university.exam.service;

import com.university.exam.entity.Section;
import com.university.exam.repository.SectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class SectionService {
    @Autowired
    private SectionRepository sectionRepository;
    public Section createSection(Section section) {
        return sectionRepository.save(section);
    }
    public Section getSectionById(Integer id) {
        return sectionRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Section not found with id " + id));
    }
    public List<Section> getAllSections() {
        return sectionRepository.findAll();
    }
    public List<Section> getSectionsByBranch(Integer branchId) {
        return sectionRepository.findByBranchId(branchId);
    }
    public Section updateSection(Integer id, Section details) {
        Section sec = getSectionById(id);
        sec.setName(details.getName());
        return sectionRepository.save(sec);
    }
    public void deleteSection(Integer id) {
        sectionRepository.deleteById(id);
    }
}