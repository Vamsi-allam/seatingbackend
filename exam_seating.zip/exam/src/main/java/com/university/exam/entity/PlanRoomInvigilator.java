package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Data
@Table(name = "plan_room_invigilator")
public class PlanRoomInvigilator {
    @EmbeddedId
    private PlanRoomInvigilatorId id;
    @MapsId("seatingPlanId")
    @ManyToOne(optional = false)
    @JoinColumn(name = "seating_plan_id", nullable = false)
    private SeatingPlan seatingPlan;
    @MapsId("roomId")
    @ManyToOne(optional = false)
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;
    @ManyToOne(optional = false)
    @JoinColumn(name = "invigilator_id", nullable = false)
    private Invigilator invigilator;
    public PlanRoomInvigilator() {
    }
    public PlanRoomInvigilator(SeatingPlan seatingPlan, Room room, Invigilator invigilator) {
        this.seatingPlan = seatingPlan;
        this.room = room;
        this.invigilator = invigilator;
        this.id = new PlanRoomInvigilatorId(seatingPlan.getId(), room.getId());
    }
}
