package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Table(name = "year_level")
public class YearLevel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String note;
}
