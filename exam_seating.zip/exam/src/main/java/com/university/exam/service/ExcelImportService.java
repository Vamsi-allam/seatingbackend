package com.university.exam.service;

import com.university.exam.dto.StudentDTO;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
@Service
public class ExcelImportService {
    public List<StudentDTO> parseStudents(MultipartFile file,
                                          Integer yearId,
                                          Integer branchId,
                                          Integer sectionId) {
        try (XSSFWorkbook wb = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = wb.getSheetAt(0);
            List<StudentDTO> out = new ArrayList<>();
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue;  // skip header
                String regNo = row.getCell(0).getStringCellValue();
                String name  = row.getCell(1).getStringCellValue();
                out.add(new StudentDTO(null, regNo, name, false, sectionId));
            }
            return out;
        } catch (IOException e) {
            throw new IllegalArgumentException("Failed to parse Excel file: " + e.getMessage());
        }
    }
}