package com.university.exam.service;

import com.university.exam.entity.Room;
import com.university.exam.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service

public class RoomService {
    @Autowired
    private RoomRepository roomRepository;
    public Room createRoom(Room room) {
        return roomRepository.save(room);
    }
    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Room not found with id " + id));
    }
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }
    public List<Room> getRoomsByFloor(Integer floorId) {
        return roomRepository.findByFloorId(floorId);
    }
    public Room updateRoom(Long id, Room details) {
        Room room = getRoomById(id);
        room.setName(details.getName());
        room.setRows(details.getRows());
        room.setCols(details.getCols());
        return roomRepository.save(room);
    }
    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }
}