package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InvigilatorDTO {
    private Long id;
    private String fullName;
    private String contactInfo;
}
