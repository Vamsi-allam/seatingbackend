package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorDTO {
    private Integer id;
    private Integer blockId;
    private Integer level;
}
