package com.university.exam.dto;
import lombok.*;
@Data
public class InvigilatorAssignment {
    private Long roomId;
    private Long invigilatorId;
    public InvigilatorAssignment() {
    }
    public InvigilatorAssignment(Long roomId, Long invigilatorId) {
        this.roomId = roomId;
        this.invigilatorId = invigilatorId;
    }
}
