package com.university.exam.service;

import com.university.exam.entity.Exam;
import com.university.exam.repository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ExamService {
    @Autowired
    private ExamRepository examRepository;
    public Exam createExam(Exam exam) {
        return examRepository.save(exam);
    }
    public Exam getExamById(Long id) {
        return examRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Exam not found with id " + id));
    }
    public List<Exam> getAllExams() {
        return examRepository.findAll();
    }
    public List<Exam> getExamsByDate(java.util.Date date) {
        return examRepository.findByExamDate(new java.sql.Date(date.getTime()));
    }
    public Exam updateExam(Long id, Exam details) {
        Exam exam = getExamById(id);
        exam.setName(details.getName());
        exam.setExamDate(details.getExamDate());
        exam.setStartTime(details.getStartTime());
        exam.setEndTime(details.getEndTime());
        return examRepository.save(exam);
    }
    public void deleteExam(Long id) {
        examRepository.deleteById(id);
    }
}

