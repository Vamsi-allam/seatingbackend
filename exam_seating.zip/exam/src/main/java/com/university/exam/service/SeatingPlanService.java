package com.university.exam.service;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

// Ensure this is the correct package for InvigilatorAssignment
import com.university.exam.dto.CreatePlanRequest;
import com.university.exam.dto.InvigilatorAssignment;
import com.university.exam.dto.RoomAdjustmentRequest;
import com.university.exam.dto.SeatingPlanDTO;
import com.university.exam.entity.Admin;
import com.university.exam.entity.Block;
import com.university.exam.entity.Exam;
import com.university.exam.entity.Invigilator;
import com.university.exam.entity.PlanRoomInvigilator;
import com.university.exam.entity.Room;
import com.university.exam.entity.SeatAssignment;
import com.university.exam.entity.SeatingPlan;
import com.university.exam.entity.Section;
import com.university.exam.entity.Student;
import com.university.exam.repository.AdminRepository;
import com.university.exam.repository.BlockRepository;
import com.university.exam.repository.ExamRepository;
import com.university.exam.repository.InvigilatorRepository;
import com.university.exam.repository.PlanRoomInvigilatorRepository;
import com.university.exam.repository.RoomRepository;
import com.university.exam.repository.SeatAssignmentRepository;
import com.university.exam.repository.SeatingPlanRepository;
import com.university.exam.repository.SectionRepository;
import com.university.exam.repository.StudentRepository;

@Service
@Transactional
public class SeatingPlanService {
    @Autowired private SeatingPlanRepository seatingPlanRepo;
    @Autowired private ExamRepository examRepo;
    @Autowired private BlockRepository blockRepo;
    @Autowired private AdminRepository adminRepo;
    @Autowired private SectionRepository sectionRepo;
    @Autowired private StudentRepository studentRepo;
    @Autowired private RoomRepository roomRepo;
    @Autowired private SeatAssignmentRepository seatAssignmentRepo;
    @Autowired private PlanRoomInvigilatorRepository planRoomInvRepo;
    @Autowired private InvigilatorRepository invigilatorRepo;
    @Autowired private RoomAllocationService roomAllocationService;
    public SeatingPlanDTO createPlan(CreatePlanRequest req) {
        // Fetch exam and block
        Exam exam = examRepo.findById(req.getExamId())
                .orElseThrow(() -> new IllegalArgumentException("Exam not found"));
        Block block = blockRepo.findById(req.getBlockId().intValue())
                .orElseThrow(() -> new IllegalArgumentException("Block not found"));
        // Get current admin from Security Context
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Admin admin = adminRepo.findByEmail(username)
                .orElseThrow(() -> new IllegalArgumentException("Admin not found"));
        // Create seating plan
        SeatingPlan plan = new SeatingPlan();
        plan.setExam(exam);
        plan.setBlock(block);
        plan.setAdmin(admin);
        seatingPlanRepo.save(plan);
        // Auto-select rooms based on total students
        Map<Long, Integer> counts = req.getSectionIds().stream()
                .collect(Collectors.toMap(
                    sid -> sid,
                    sid -> studentRepo.countBySectionId(sid)
                ));
        List<Room> rooms = roomAllocationService.allocateRooms(block.getId(), counts);
        plan.setRooms(rooms);
        seatingPlanRepo.save(plan);
        return toDTO(plan);
    }
    public SeatingPlanDTO updateRooms(Long planId, RoomAdjustmentRequest req) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        plan.getRooms().clear();
        List<Room> rooms = roomRepo.findAllById(req.getRoomIds());
        plan.getRooms().addAll(rooms);
        seatingPlanRepo.save(plan);
        return toDTO(plan);
    }
    public SeatingPlanDTO finalizePlan(Long planId, List<InvigilatorAssignment> invs) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        // Clear existing assignments
        seatAssignmentRepo.deleteBySeatingPlanId(planId);
        planRoomInvRepo.deleteBySeatingPlanId(planId);
        // Assign invigilators
        for (InvigilatorAssignment a : invs) {
            Invigilator inv = invigilatorRepo.findById(a.getInvigilatorId())
                    .orElseThrow(() -> new IllegalArgumentException("Invigilator not found"));
            planRoomInvRepo.save(new PlanRoomInvigilator(plan, roomRepo.getReferenceById(a.getRoomId()), inv));
        }
        // Fetch students for all sections in this plan
        List<Section> secs = sectionRepo.findAllById(plan.getSectionIds());
        List<Student> students = secs.stream()
                .flatMap(sec -> studentRepo.findBySectionId(sec.getId().longValue()).stream())
                .collect(Collectors.toList());
        // Assign seats
        List<SeatAssignment> assignments = roomAllocationService.assignSeats(plan, students);
        seatAssignmentRepo.saveAll(assignments);
        return toDTO(plan);
    }
    @Transactional(readOnly = true)
    public SeatingPlanDTO getPlan(Long planId) {
        SeatingPlan plan = seatingPlanRepo.findById(planId)
                .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
        return toDTO(plan);
    }
    public SeatingPlanDTO regeneratePlan(Long planId) {
        // Remove old assignment
        seatAssignmentRepo.deleteBySeatingPlanId(planId);
        planRoomInvRepo.deleteBySeatingPlanId(planId);
        // Reapply with previous invigilator assignments
        List<InvigilatorAssignment> prev = planRoomInvRepo.findBySeatingPlanId(planId).stream()
                .map(pi -> new InvigilatorAssignment(pi.getRoom().getId(), pi.getInvigilator().getId()))
                .collect(Collectors.toList());
        return finalizePlan(planId, prev);
    }
    public void deletePlan(Long planId) {
        seatingPlanRepo.deleteById(planId);
    }
    // Helper to map entity to DTO
    private SeatingPlanDTO toDTO(SeatingPlan p) {
        // TODO: implement mapping logic
        return new SeatingPlanDTO();
    }

}
// @Service

// @Transactional
// public class SeatingPlanService {
//     @Autowired private SeatingPlanRepository seatingPlanRepo;
//     @Autowired private ExamRepository examRepo;
//     @Autowired private BlockRepository blockRepo;
//     @Autowired private SectionRepository sectionRepo;
//     @Autowired private StudentRepository studentRepo;
//     @Autowired private RoomRepository roomRepo;
//     @Autowired private SeatAssignmentRepository seatAssignmentRepo;
//     @Autowired private PlanRoomInvigilatorRepository planRoomInvRepo;
//     @Autowired private InvigilatorRepository invigilatorRepo;
//     @Autowired private RoomAllocationService roomAllocationService;
//     public SeatingPlanDTO createPlan(CreatePlanRequest req) {
//         Exam exam = examRepo.findById(req.getExamId())
//             .orElseThrow(() -> new IllegalArgumentException("Exam not found"));
//         Block block = blockRepo.findById(req.getBlockId().intValue())
//             .orElseThrow(() -> new IllegalArgumentException("Block not found"));
//         String username = SecurityContextHolder.getContext()
//             .getAuthentication().getName();
//         Admin admin = adminRepo.findByEmail(username)
//             .orElseThrow(() -> new IllegalArgumentException("Admin not found"));
//         SeatingPlan plan = new SeatingPlan();
//         plan.setExam(exam);
//         plan.setBlock(block);
//         plan.setAdmin(admin);
//         // assume AdminDetails holds current admin ID
//         Long adminId = ((CustomUserDetails)SecurityContextHolder.getContext()
//                               .getAuthentication().getPrincipal()).getId();
//         plan.setAdmin(new Admin(adminId));
//         seatingPlanRepo.save(plan);
//         // auto‐select rooms
//         Map<Long,Integer> counts = req.getSectionIds().stream()
//             .collect(Collectors.toMap(sid ->
//                     sid,
//                 sid -> studentRepo.countBySectionId(sid)
//             ));
//         List<Room> rooms = roomAllocationService.allocateRooms(block.getId(), counts);
//         plan.setRooms(rooms);
//         seatingPlanRepo.save(plan);
//         return toDTO(plan);
//     }
//     public SeatingPlanDTO updateRooms(Long planId, RoomAdjustmentRequest req) {
//         SeatingPlan plan = seatingPlanRepo.findById(planId)
//             .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
//         plan.getRooms().clear();
//         List<Room> rooms = roomRepo.findAllById(req.getRoomIds());
//         plan.getRooms().addAll(rooms);
//         seatingPlanRepo.save(plan);
//         return toDTO(plan);
//     }
//     public SeatingPlanDTO finalizePlan(Long planId, List<InvigilatorAssignment> invs) {
//         SeatingPlan plan = seatingPlanRepo.findById(planId)
//             .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
//         // clear old assignments
//         seatAssignmentRepo.deleteBySeatingPlanId(planId);
//         planRoomInvRepo.deleteBySeatingPlanId(planId);
//         // assign invigilators
//         for (InvigilatorAssignment a : invs) {
//             Invigilator inv = invigilatorRepo.findById(a.getInvigilatorId())
//                 .orElseThrow(() -> new IllegalArgumentException("Invigilator not found"));
//             planRoomInvRepo.save(new PlanRoomInvigilator(plan, roomRepo.getOne(a.getRoomId()), inv));
//         }
//         // assign seats
//         List<Student> students = reqSections(plan).stream()
//             .flatMap(sec -> studentRepo.findBySection(sec).stream())
//             .collect(Collectors.toList());
//         List<SeatAssignment> assigns = roomAllocationService.assignSeats(plan, students);
//         seatAssignmentRepo.saveAll(assigns);
//         return toDTO(plan);
//     }
//     public SeatingPlanDTO regeneratePlan(Long planId) {
//         deleteAssignments(planId);
//         // reuse previous inv assignments
//         List<InvigilatorAssignment> prev = planRoomInvRepo.findBySeatingPlanId(planId).stream()
//             .map(pi -> new InvigilatorAssignment(pi.getRoom().getId(), pi.getInvigilator().getId()))
//             .collect(Collectors.toList());
//         return finalizePlan(planId, prev);
//     }
//     @Transactional(readOnly = true)
//     public SeatingPlanDTO getPlan(Long planId) {
//         SeatingPlan plan = seatingPlanRepo.findById(planId)
//             .orElseThrow(() -> new IllegalArgumentException("Plan not found"));
//         return toDTO(plan);
//     }
//     public void deletePlan(Long planId) {
//         seatingPlanRepo.deleteById(planId);
//     }
//     // ────────────── helpers ─────────────────
//     private void deleteAssignments(Long planId) {
//         seatAssignmentRepo.deleteBySeatingPlanId(planId);
//         planRoomInvRepo.deleteBySeatingPlanId(planId);
//     }
//     private List<Section> reqSections(SeatingPlan plan) {
//         // assume SeatingPlan stores sectionIds
//         return sectionRepo.findAllById(plan.getSectionIds());
//     }
//     private SeatingPlanDTO toDTO(SeatingPlan p) {
//         // map entity → DTO as needed
//         return new SeatingPlanDTO(/*…*/);
//     }
// }

