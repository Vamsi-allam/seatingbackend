package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SectionDTO {
    private Integer id;
    private String name;
    private Integer branchId;
}
