package com.university.exam.entity;

import lombok.*;
import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import java.sql.Timestamp;
@Entity
@Data
@Table(name = "invigilator")
public class Invigilator {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    private String contactInfo;

    @CreationTimestamp
    private Timestamp createdAt;
}
