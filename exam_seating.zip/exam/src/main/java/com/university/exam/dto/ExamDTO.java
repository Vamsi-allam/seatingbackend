package com.university.exam.dto;

import lombok.*;
import java.sql.Date;
import java.sql.Time;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExamDTO {
    private Long id;
    private String name;
    private Date examDate;
    private Time startTime;
    private Time endTime;
}
