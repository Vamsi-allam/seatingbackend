package com.university.exam.dto;

import lombok.*;
import java.util.List;
@Data
public class CreatePlanRequest {
    private Long ExamId;
    private Long blockId;
    private List<Long> sectionIds;
    public CreatePlanRequest(Long examId, Long blockId, List<Long> sectionIds) {
        ExamId = examId;
        this.blockId = blockId;
        this.sectionIds = sectionIds;
    }
}
