package com.university.exam.dto;

import lombok.*;
import java.sql.Timestamp;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SeatingPlanDTO {
    private Long id;
    private Long examId;
    private Long blockId;
    private Long createdBy;
    private Timestamp createdAt;
}
