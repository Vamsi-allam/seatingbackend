package com.university.exam.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
// import removed as ResourceNotFoundException is not used
import com.university.exam.entity.YearLevel;
import com.university.exam.repository.YearLevelRepository;
import java.util.List;
@Service
public class YearLevelService {
    @Autowired
    private YearLevelRepository yearLevelRepository;
    public YearLevel createYearLevel(YearLevel yearLevel) {
        return yearLevelRepository.save(yearLevel);
    }
    public YearLevel getYearLevelById(Integer id) {
        return yearLevelRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("YearLevel not found with id " + id));
    }
    public List<YearLevel> getAllYearLevels() {
        return yearLevelRepository.findAll();
    }
    public YearLevel updateYearLevel(Integer id, YearLevel details) {
        YearLevel yl = getYearLevelById(id);
        yl.setName(details.getName());
        yl.setNote(details.getNote());
        return yearLevelRepository.save(yl);
    }
    public void deleteYearLevel(Integer id) {
        yearLevelRepository.deleteById(id);
    }
}