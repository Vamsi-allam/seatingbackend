package com.university.exam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.university.exam.entity.Invigilator;
import com.university.exam.repository.InvigilatorRepository;
@Service
public class InvigilatorService {
    @Autowired
    private InvigilatorRepository invigilatorRepository;
    public Invigilator createInvigilator(Invigilator invigilator) {
        return invigilatorRepository.save(invigilator);
    }
    public Invigilator getInvigilatorById(Long id) {
        return invigilatorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Invigilator not found with id " + id ));
    }
    public List<Invigilator> getAllInvigilators() {
        return invigilatorRepository.findAll();
    }
    public Invigilator updateInvigilator(Long id, Invigilator details) {
        Invigilator inv = getInvigilatorById(id);
        inv.setFullName(details.getFullName());
        inv.setContactInfo(details.getContactInfo());
        return invigilatorRepository.save(inv);
    }
    public void deleteInvigilator(Long id) {
        invigilatorRepository.deleteById(id);
    }
}
