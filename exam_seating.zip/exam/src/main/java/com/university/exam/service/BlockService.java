package com.university.exam.service;

import com.university.exam.entity.Block;
import com.university.exam.repository.BlockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class BlockService {
    @Autowired
    private BlockRepository blockRepository;
    public Block createBlock(Block block) {
        return blockRepository.save(block);
    }
    public Block getBlockById(Integer id) {
        return blockRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Block not found with id " + id));
    }
    public List<Block> getAllBlocks() {
        return blockRepository.findAll();
    }
    public Block updateBlock(Integer id, Block details) {
        Block block = getBlockById(id);
        block.setName(details.getName());
        return blockRepository.save(block);
    }
    public void deleteBlock(Integer id) {
        blockRepository.deleteById(id);
    }
}

