package com.university.exam.dto;

import lombok.*;
@Data
public class PlanRoomInvigilatorDTO {
    private Long seatingPlanId;
    private Long roomId;
    private Long invigilatorId;

    public PlanRoomInvigilatorDTO() {
    }
    public PlanRoomInvigilatorDTO(Long seatingPlanId, Long roomId, Long invigilatorId) {
        this.seatingPlanId = seatingPlanId;
        this.roomId = roomId;
        this.invigilatorId = invigilatorId;
    }
}
