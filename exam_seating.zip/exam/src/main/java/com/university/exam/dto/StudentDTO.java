package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StudentDTO {
    private Long id;
    private String regNo;
    private String fullName;
    private Boolean blocked;
    private Long sectionId;

    public StudentDTO(Long id, String regNo, String fullName, Boolean blocked, Integer sectionId) {
        this.id = id;
        this.regNo = regNo;
        this.fullName = fullName;
        this.blocked = blocked;
        this.sectionId = sectionId != null ? Long.valueOf(sectionId) : null;
    }
}
