package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class YearLevelDTO {
    private Integer id;
    private String name;
    private String note;
}
