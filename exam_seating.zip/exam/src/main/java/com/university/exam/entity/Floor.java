package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Data
@Table(name = "floor")
public class Floor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "block_id", nullable = false)
    private Block block;
    private Integer level;
}
