package com.university.exam.service;

import com.university.exam.entity.Student;
import com.university.exam.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;
    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }
    public Student getStudentById(Long id) {
        return studentRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Student not found with id " + id));
    }
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    public List<Student> getStudentsBySection(Long sectionId) {
        return studentRepository.findBySectionId(sectionId);
    }
    public Student getStudentByRegNo(String regNo) {
        return studentRepository.findByRegNo(regNo)
          .orElseThrow(() -> new IllegalArgumentException("Student not found with regNo " + regNo));
    }
    public Student updateStudent(Long id, Student details) {
        Student student = getStudentById(id);
        student.setFullName(details.getFullName());
        student.setBlocked(details.getBlocked());
        return studentRepository.save(student);
    }
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
}