package com.university.exam.service;

import com.university.exam.entity.ExamSubject;
import com.university.exam.repository.ExamSubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ExamSubjectService {
    @Autowired
    private ExamSubjectRepository examSubjectRepository;
    public ExamSubject createExamSubject(ExamSubject es) {
        return examSubjectRepository.save(es);
    }
    public ExamSubject getExamSubjectById(Long id) {
        return examSubjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("ExamSubject not found with id " + id));
    }
    public List<ExamSubject> getAllExamSubjects() {
        return examSubjectRepository.findAll();
    }
    public List<ExamSubject> getByExamId(Long examId) {
        return examSubjectRepository.findByExamId(examId);
    }
    public ExamSubject updateExamSubject(Long id, ExamSubject details) {
        ExamSubject es = getExamSubjectById(id);
        es.setSetNumber(details.getSetNumber());
        return examSubjectRepository.save(es);
    }
    public void deleteExamSubject(Long id) {
        examSubjectRepository.deleteById(id);
    }
}


