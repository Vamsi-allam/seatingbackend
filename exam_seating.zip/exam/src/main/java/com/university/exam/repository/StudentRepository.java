package com.university.exam.repository;

import com.university.exam.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.university.exam.entity.Section;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findBySectionId(Long sectionId);
    Optional<Student> findByRegNo(String regNo);
    @Query("SELECT COUNT(s) FROM Student s WHERE s.section.id = :sectionId")
    Integer countBySectionId(@Param("sectionId") Long sectionId);
    List<Student> findBySection(Section section);
}
