package com.university.exam.service;

import com.university.exam.entity.Subject;
import com.university.exam.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class SubjectService {
    @Autowired
    private SubjectRepository subjectRepository;
    public Subject createSubject(Subject subject) {
        return subjectRepository.save(subject);
    }
    public Subject getSubjectById(Long id) {
        return subjectRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Subject not found with id " + id));
    }
    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }
    public Subject updateSubject(Long id, Subject details) {
        Subject subj = getSubjectById(id);
        subj.setCode(details.getCode());
        subj.setTitle(details.getTitle());
        return subjectRepository.save(subj);
    }
    public void deleteSubject(Long id) {
        subjectRepository.deleteById(id);
    }
}