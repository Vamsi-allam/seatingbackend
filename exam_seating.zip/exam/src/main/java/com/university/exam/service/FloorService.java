package com.university.exam.service;

import com.university.exam.entity.Floor;
import com.university.exam.repository.FloorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class FloorService {
    @Autowired
    private FloorRepository floorRepository;
    public Floor createFloor(Floor floor) {
        return floorRepository.save(floor);
    }
    public Floor getFloorById(Integer id) {
        return floorRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Floor not found with id " + id));
    }
    public List<Floor> getAllFloors() {
        return floorRepository.findAll();
    }
    public List<Floor> getFloorsByBlock(Integer blockId) {
        return floorRepository.findByBlockId(blockId);
    }
    public Floor updateFloor(Integer id, Floor details) {
        Floor floor = getFloorById(id);
        floor.setLevel(details.getLevel());
        return floorRepository.save(floor);
    }
    public void deleteFloor(Integer id) {
        floorRepository.deleteById(id);
    }
}