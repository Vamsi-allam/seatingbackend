package com.university.exam.service;

import com.university.exam.entity.Branch;
import com.university.exam.repository.BranchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class BranchService {
    @Autowired
    private BranchRepository branchRepository;
    public Branch createBranch(Branch branch) {
        return branchRepository.save(branch);
    }
    public Branch getBranchById(Integer id) {
        return branchRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Branch not found with id " + id));
    }
    public List<Branch> getAllBranches() {
        return branchRepository.findAll();
    }
    public List<Branch> getBranchesByYear(Integer yearId) {
        return branchRepository.findByYearLevelId(Integer.toString(yearId));
    }
    public Branch updateBranch(Integer id, Branch details) {
        Branch branch = getBranchById(id);
        branch.setName(details.getName());
        return branchRepository.save(branch);
    }
    public void deleteBranch(Integer id) {

        branchRepository.deleteById(id);
    }
}