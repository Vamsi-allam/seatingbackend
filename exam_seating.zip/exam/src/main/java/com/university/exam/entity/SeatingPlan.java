package com.university.exam.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import java.sql.Timestamp;
import java.util.List;
@Entity
@Data
@Table(name = "seating_plan")
public class SeatingPlan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "exma_id", nullable = false)
    private Exam exam;
    @ManyToOne
    @JoinColumn(name = "block_id", nullable = false)
    private Block block;
    @ManyToOne
    @JoinColumn(name = "created_by", nullable = false)
    private Admin admin;
    @CreationTimestamp
    private Timestamp createdAt;
    @ManyToOne
    @JoinTable(
        name = "plan_room_invigilator",
        joinColumns = @JoinColumn(name = "seating_plan_id"),
        inverseJoinColumns = @JoinColumn(name = "room_id")
    )
    private List<Room> rooms;
    public List<Room> getRooms() {
        return rooms;
    }
    public void setRooms(List<Room> rooms) {
        this.rooms = rooms;
    }
    public Iterable<Integer> getSectionIds() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getSectionIds'");
    }
}
