package com.university.exam.entity;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.*;
import lombok.Data;
import java.sql.Timestamp;
@Data
@Entity
@Table(name = "student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String regNo;

    private String fullName;
    @ManyToOne
    @JoinColumn(name = "section_id", nullable = false)
    private Section section;
    private Boolean blocked = false;
    @CreationTimestamp
    private Timestamp createdAt;
}
