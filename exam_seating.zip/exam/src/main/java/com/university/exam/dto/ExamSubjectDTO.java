package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExamSubjectDTO {
    private Long id;
    private Long examId;
    private Long subjectId;
    private Integer setNumber;
}
