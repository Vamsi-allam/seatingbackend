package com.university.exam.service;

import com.university.exam.entity.SeatAssignment;
import com.university.exam.repository.SeatAssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class SeatAssignmentService {
    @Autowired
    private SeatAssignmentRepository seatAssignmentRepository;
    public SeatAssignment createSeatAssignment(SeatAssignment sa) {
        return seatAssignmentRepository.save(sa);
    }
    public SeatAssignment getSeatAssignment(Long id) {
        return seatAssignmentRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("SeatAssignment not found with id " + id));
    }
    public List<SeatAssignment> getAssignmentsByPlan(Long planId) {
        return seatAssignmentRepository.findBySeatingPlanId(planId);
    }
    public void deleteSeatAssignment(Long id) {
        seatAssignmentRepository.deleteById(id);
    }
}