package com.university.exam.dto;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchDTO {
    private Integer id;
    private String name;
    private Integer yearId;
}
